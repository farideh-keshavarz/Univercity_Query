﻿--تمرینات جلسه چهارم/ دیتابیس دانشگاه--------------------------------------------------------------------------------------------
use [Univercity]
-- -1- نام دانشجویانی را بیابید که در نیمسال اول 80 درس پایگاه داده ها را گرفته اند
select student.Sname from student,course,G where G.Term#=811 and student.startYear=80 and course.Cname=N'پایگاه داده ها' and G.St#=student.st# and G.Crs#=course.Crs#

-- -2- نام دانشجویانی را بیابید که در نیمسال اول 80 درس پایگاه داده ها را نگرفته اند.
select distinct student.Sname from student,course,G where G.Term#<>811 and student.startYear<>80 and course.Cname<>N'پایگاه داده ها' and G.St#=student.st# and G.Crs#=course.Crs#

-- -3- نام دانشجویانی را بیابید که در نیمسال اول 80 هیچ درسی نگرفته اند
select student.Sname from student where student.startYear<>80 and not exists (select * from G where G.St#=student.st# and G.Term#<>811)

-- -4- لیستی از نام دروس تخصصی رشته مهندسی کامپیوتر تهیه کنید
select course.Cname from field,course,cf where field.fieldName=N'مهندسی کامپیوتر' and field.field#=CF.Field# and course.crs#=cf.crs# and cf.kind_id=2

-- -5- تعداد دروس تخصصی رشته مهندسی کامپیوتر را به دست آورید
select count(*) from field,course,cf where field.fieldName=N'مهندسی کامپیوتر' and field.field#=CF.Field# and course.crs#=cf.crs# and cf.kind_id=2

-- -6- لیستی از شماره دانشجویان مهندسی کامپیوتر و تعداد کل درسهای تخصصی گذرانده شده توسط هر یک از آنها تهیه کنید
-- قسمت اول سوال -- لیستی از شماره دانشجویان مهندسی کامپیوتر
select student.st# from field,student where field.fieldName=N'مهندسی کامپیوتر' and student.Field#=field.field#
-- قسمت دوم سوال -- تعداد دروس تخصصی رشته مهندسی کامپیوتر
select count(*) from field,course,cf where field.fieldName=N'مهندسی کامپیوتر' and field.field#=CF.Field# and course.crs#=cf.crs# and cf.kind_id=2
-- جواب کامل
select student.st#,COUNT(distinct G.Crs#) from G,field,student,cf where field.fieldName=N'مهندسی کامپیوتر' and field.field#=CF.Field# and G.crs#=cf.crs# and cf.kind_id=2 and grade>=10 and student.st#=G.St# group by student.st#

-- -7-** شماره دانشجویان مهندسی کامپیوتری را بیابید که کلیه درسهای تخصصی رشته خود را گذرانده اند
-- دانشجویان رشته کامپیوتر
select student.Sname from field,student where field.fieldName=N'مهندسی کامپیوتر' and student.Field#=field.field#
--دروس تخصصی رشته کامپیوتر
select course.Cname from field,course,cf where field.fieldName=N'مهندسی کامپیوتر' and field.field#=CF.Field# and course.crs#=cf.crs# and cf.kind_id=2
-- جواب کامل

-- -8-** شماره دانشجویان مهندسی کامپیوتری را بیابید  که کلیه درسهای تخصصی رشته خود را نگذرانده اند

-- -9-** شماره دانشجویان مهندسی کامپیوتری را بیابید که درس تخصصی مربوط به مهندسی کامپیوتر وجود دارد که این دانشجویان آنها را نگذرانده باشد

-- -10- لیستی از شماره دانشجویان و تعداد کل واحدهای گذرانده شده توسط هر یک از آنها تهیه کنید
-- تعداد واحد مربوط به دروس مردود شده لحاظ شده است
select G.st#,Sum(course.unit) from G,course where G.crs#=course.crs# group by G.st#
-- تعداد واحد مربوط به دروس مردود شده لحاظ نشده است
select G.st#,Sum(course.unit) from G,course where G.crs#=course.crs# and G.grade>=10 group by G.st#


-- -11- لیستی از نام کلیه دانشجویان و تعداد کل واحدهای گذرانده شده توسط هر یک از آنها تهیه کنید
-- واحد های گذرانده شده هر دانشجو بدون دروس پیشنیاز
select student.Sname,Sum(course.unit) from G,course,student where G.grade>=10 and G.crs#=course.crs# and G.st#=student.st# group by student.Sname 

--** واحد های گذرانده شده هر دانشجو با درنظر گرفتن دروس پیشنیاز


-- -12- لیستی از شماره دانشجویان که مجموعا بیش از 100 واحد درس گذرانده اند تهیه کنید
-- دروس پیشنیاز محاسبه نشده است
select G.St# from G,course where G.grade>=10 and G.Crs#=course.Crs# group by G.St# having Sum(course.Unit)>100

-- -13- لیستی از نام دانشجویانی که مجموعا بیش از 100 واحد درس گذرانده اند تهیه کنید
-- دروس پیشنیاز محاسبه نشده است
select student.Sname from G,course,student where G.grade>=10 and G.Crs#=course.Crs# and student.st#=G.St# group by G.St#,student.Sname having Sum(course.Unit)>100

-- -14- لیستی از شماره دانشجویی کلیه دانشجویان ورودی 80 و معدل هر یک از آنها در نیمسال اول 81 تهیه کنید
select AVG(G.grade),student.st# from student,G where student.startYear=80 and student.st#=G.St# and G.Term#=811 group by student.st#

-- -15- لیستی از نام  دانشجویان ورودی 80 و معدل هر یک از آنها در نیمسال اول 81  بیشتر از 18 بوده است تهیه کنید
-- نیم سال اول 81 را مطمئن نیستم
select student.Sname from student,G where student.startYear=80 and student.st#=G.St# and G.Term#=811 group by student.Sname,student.st# having AVG(G.grade)>18

-- -16- لیستی از نام اساتیدی که  درس پایگاه داده ها را تدریس کرده اند را تهیه کنید
select distinct prof.Pname from prof,course,pc where prof.Prof#=PC.Prof# and PC.Course#=course.Crs# and course.Cname=N'پایگاه داده ها'

-- -17- لیستی از شماره اساتیدی که درس پایگاه داده ها را بیش از چهار ترم تدریس کرده اند تهیه کنید
select distinct PC.Prof# from PC,course where PC.Course#=course.Crs# and course.Cname=N'پایگاه داده ها' group by PC.Course#,PC.Prof# having COUNT(distinct PC.term#)>4

-- -18- لیستی از نام دروس عملی تهیه کنید که توسط استاد شماره 100 در نیمسال دوم 83 تدریس شده اند
-- نیم سال دوم 83 لحاظ نشده
select course.Cname from course,PC where course.Crs#=PC.Course# and PC.Prof#=100 and course.Type#=2

-- -19- لیستی از شماره دورسی تهیه کنید که پیش نیاز درس پایگاه داده ها هستند
select pre.Pre# from course, pre where course.Cname=N'پایگاه داده ها' and course.Crs#=pre.Crs#

-- -20- لیستی از نام دروسی تهیه کنید که پیش نیاز درس پایگاه داده ها هستند
select course.Cname from course, pre where course.Crs#=pre.Pre# and pre.Crs#=1407

